'use strict';
const { loadConfig } = require('../src/config');
const { createServer } = require('../src/server');
const { openDatabase } = require('../src/db/database');
const { createLogger } = require('../src/logger');

/** Starts a real HTTP server on a random port backed by an in-memory SQLite database. */
async function startTestServer(env = {}, opts = {}) {
  const config = loadConfig({ PORT: '0', LOG_LEVEL: 'silent', ...env });
  const logs = [];
  const logger = createLogger({ level: opts.logLevel || 'silent', stream: { write: (l) => logs.push(l) } });
  const { server, container } = createServer(config, { logger, db: openDatabase(':memory:'), clock: opts.clock });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  const close = () => new Promise((resolve) => { server.closeAllConnections(); server.close(() => { try { container.close(); } catch { /* already closed by the test */ } resolve(); }); });
  return { base, close, logs, container, config };
}

const post = (url, body, headers = {}) => fetch(url, {
  method: 'POST', headers: { 'Content-Type': 'application/json', ...headers },
  body: typeof body === 'string' ? body : JSON.stringify(body),
});

module.exports = { startTestServer, post };
