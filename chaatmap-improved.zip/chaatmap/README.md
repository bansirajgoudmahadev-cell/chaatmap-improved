# ChaatMap – StreetBite Safety

Community hygiene scores for street-food vendors (Hyderabad demo). Node.js + SQLite, **zero runtime dependencies**.

## Quick start
Requires **Node 22.5+** (uses built-in `node:sqlite` and `node:test`).

```bash
npm start            # http://127.0.0.1:3000   (report page: /report.html)
npm test             # 52 tests
npm run test:coverage
```
Copy `.env.example` to `.env` to change port, rate limits, CORS origins, etc. Set `HOST=0.0.0.0` to expose it on your network.

## Architecture
```
public/            PWA frontend (service worker, offline cache + review queue)
src/app.js         request pipeline: request-id → security headers → CORS → rate limit → router → error handler
src/http/          router, middleware (CSP, CORS, body parser, static), rate limiter
src/services/      Vendor / Review / Trail services, HygieneService (Strategy: flat | time-decay)
src/repositories/  all SQL (bound parameters only)
src/db/            schema, WAL, indexes, seed data
src/container.js   composition root (dependency injection)
test/              unit, repository, service and HTTP integration tests
```

## API
| Method | Path | Notes |
|---|---|---|
| GET | `/api/health` | liveness + DB check |
| GET | `/api/vendors?q=&area=&specialty=` | vendors with hygiene score, grade, trust |
| GET | `/api/vendors/:id` | one vendor |
| GET | `/api/vendors/:id/reviews?limit=` | recent reviews |
| POST | `/api/vendors/:id/reviews` | `{water,covered,gloves,surroundings (1-5), comment?, photo?}` |
| GET | `/api/trail?limit=` | top hygiene food trail |
| GET | `/api/stats` | vendor count, review count, top score |

Score = water 40% + covered 25% + gloves 20% + surroundings 15%, with each review weighted by `0.5^(age/halfLifeDays)`.

*Demo data only. This is community information, not a food-safety certification.*
