'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { openDatabase } = require('../src/db/database');
const { seedIfEmpty } = require('../src/db/seed');
const { VendorRepository } = require('../src/repositories/vendorRepository');
const { ReviewRepository } = require('../src/repositories/reviewRepository');

function setup() {
  const db = openDatabase(':memory:');
  seedIfEmpty(db, Date.parse('2026-01-01T00:00:00Z'));
  return { db, vendors: new VendorRepository(db), reviews: new ReviewRepository(db) };
}

test('schema has the locality index and foreign keys on', () => {
  const { db } = setup();
  const names = db.prepare("PRAGMA index_list('vendors')").all().map((i) => i.name);
  assert.ok(names.includes('idx_vendors_locality'));
  assert.equal(db.prepare('PRAGMA foreign_keys').get().foreign_keys, 1);
});

test('seeding is idempotent', () => {
  const { db } = setup();
  assert.equal(seedIfEmpty(db), false);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM vendors').get().n, 6);
});

test('search by area, specialty and free text (case-insensitive)', () => {
  const { vendors } = setup();
  assert.equal(vendors.search({}).length, 6);
  assert.deepEqual(vendors.search({ area: 'Sindhi Colony' }).map((v) => v.id).sort(), [1, 6]);
  assert.equal(vendors.search({ specialty: 'Momos' })[0].name, 'Madhapur Momos Hub');
  assert.equal(vendors.search({ q: 'DOSA' })[0].id, 2);
  assert.equal(vendors.search({ q: 'dosa', area: 'Old City' }).length, 0);
});

test('LIKE wildcards in user input are matched literally', () => {
  const { vendors } = setup();
  assert.equal(vendors.search({ q: '%' }).length, 0);
  assert.equal(vendors.search({ q: '_' }).length, 0);
});

test('SQL injection strings are treated as data', () => {
  const { vendors, db } = setup();
  assert.equal(vendors.search({ q: "'; DROP TABLE vendors; --" }).length, 0);
  assert.equal(vendors.search({ area: "x' OR '1'='1" }).length, 0);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM vendors').get().n, 6);
});

test('findById maps booleans and returns null when missing', () => {
  const { vendors } = setup();
  assert.equal(vendors.findById(1).fssai, true);
  assert.equal(vendors.findById(5).open, false);
  assert.equal(vendors.findById(999), null);
});

test('reviews: add, recent ordering, grouped scoring rows, count', () => {
  const { reviews } = setup();
  const before = reviews.count();
  const saved = reviews.add({ vendorId: 2, water: 5, covered: 5, gloves: 5, surroundings: 5, comment: 'great', createdAt: '2027-01-01T00:00:00.000Z' });
  assert.ok(saved.id > 0);
  assert.equal(reviews.count(), before + 1);
  assert.equal(reviews.recentForVendor(2, 1)[0].comment, 'great');
  const grouped = reviews.scoringRowsFor([1, 2]);
  assert.equal(grouped.get(1).length, 8);
  assert.equal(grouped.get(2).length, 7);
  assert.equal(reviews.scoringRowsFor([]).size, 0);
});

test('foreign key and CHECK constraints are enforced', () => {
  const { reviews } = setup();
  assert.throws(() => reviews.add({ vendorId: 999, water: 3, covered: 3, gloves: 3, surroundings: 3, createdAt: 'x' }));
  assert.throws(() => reviews.add({ vendorId: 1, water: 9, covered: 3, gloves: 3, surroundings: 3, createdAt: 'x' }));
});
