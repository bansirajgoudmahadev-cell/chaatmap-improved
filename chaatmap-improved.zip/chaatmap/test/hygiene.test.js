'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { HygieneService, FlatStrategy, TimeDecayStrategy, DEFAULT_WEIGHTS, gradeFor } = require('../src/services/hygieneService');

const NOW = Date.parse('2026-01-01T00:00:00Z');
const daysAgo = (d) => new Date(NOW - d * 86400000).toISOString();
const review = (w, c, g, s, d = 0) => ({ water: w, covered: c, gloves: g, surroundings: s, created_at: daysAgo(d) });
const flat = new HygieneService({ strategy: new FlatStrategy() });

test('weights sum to exactly 1 and match the spec (40/25/20/15)', () => {
  assert.deepEqual({ ...DEFAULT_WEIGHTS }, { water: 0.4, covered: 0.25, gloves: 0.2, surroundings: 0.15 });
  assert.ok(Math.abs(Object.values(DEFAULT_WEIGHTS).reduce((a, b) => a + b, 0) - 1) < 1e-12);
});

test('weighted formula: 5,5,4,5 => 4.80 (matches original app)', () => {
  assert.equal(flat.assess([review(5, 5, 4, 5)], NOW).score, 4.8);
});

test('bounds: all 5s => 5, all 1s => 1', () => {
  assert.equal(flat.assess([review(5, 5, 5, 5)], NOW).score, 5);
  assert.equal(flat.assess([review(1, 1, 1, 1)], NOW).score, 1);
});

test('water has the heaviest weight', () => {
  const waterBad = flat.assess([review(1, 5, 5, 5)], NOW).score;
  const surroundBad = flat.assess([review(5, 5, 5, 1)], NOW).score;
  assert.ok(waterBad < surroundBad);
});

test('averages several reviews per factor', () => {
  const r = flat.assess([review(5, 5, 5, 5), review(1, 1, 1, 1)], NOW);
  assert.equal(r.score, 3);
  assert.deepEqual(r.factors, { water: 3, covered: 3, gloves: 3, surroundings: 3 });
});

test('no reviews => Unrated, null score, zero trust', () => {
  assert.deepEqual(flat.assess([], NOW), {
    score: null, grade: 'Unrated', trust: 0, reviewCount: 0,
    factors: { water: null, covered: null, gloves: null, surroundings: null },
  });
});

test('time decay: a review one half-life old counts half as much', () => {
  const svc = new HygieneService({ strategy: new TimeDecayStrategy(45) });
  // weights 1 (new, all 5) and 0.5 (45 days old, all 1) => (5 + 0.5) / 1.5 = 3.67
  assert.equal(svc.assess([review(5, 5, 5, 5, 0), review(1, 1, 1, 1, 45)], NOW).score, 3.67);
});

test('time decay: newest feedback moves the score more than flat averaging', () => {
  const rows = [review(5, 5, 5, 5, 0), review(1, 1, 1, 1, 200)];
  const decayed = new HygieneService({ strategy: new TimeDecayStrategy(45) }).assess(rows, NOW).score;
  assert.ok(decayed > flat.assess(rows, NOW).score);
});

test('very old reviews never produce NaN or zero weight', () => {
  const svc = new HygieneService({ strategy: new TimeDecayStrategy(1) });
  const r = svc.assess([review(3, 3, 3, 3, 100000)], NOW);
  assert.equal(r.score, 3);
});

test('trust grows with review volume and falls when reviews are stale', () => {
  const svc = new HygieneService({ strategy: new TimeDecayStrategy(45) });
  const few = svc.assess([review(4, 4, 4, 4)], NOW).trust;
  const many = svc.assess(Array.from({ length: 10 }, () => review(4, 4, 4, 4)), NOW).trust;
  const stale = svc.assess(Array.from({ length: 10 }, () => review(4, 4, 4, 4, 400)), NOW).trust;
  assert.ok(many > few);
  assert.ok(stale < many);
  assert.ok(many <= 100 && stale >= 0);
});

test('gradeFor thresholds', () => {
  assert.deepEqual([4.5, 3.5, 2.5, 2.49, null].map(gradeFor), ['Excellent', 'Good', 'Fair', 'Poor', 'Unrated']);
});

test('constructor rejects invalid weights and half-life', () => {
  assert.throws(() => new HygieneService({ weights: { water: 0.5, covered: 0.5, gloves: 0.5, surroundings: 0.5 } }), RangeError);
  assert.throws(() => new TimeDecayStrategy(0), RangeError);
});
