'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { sanitizeText, escapeLike } = require('../src/utils/sanitize');
const { validateReviewInput, parseId, parseLimit, parseFilters } = require('../src/utils/validate');
const { ValidationError } = require('../src/errors');
const { createLogger } = require('../src/logger');
const { loadConfig } = require('../src/config');

test('sanitizeText strips tags, control chars and collapses whitespace', () => {
  assert.equal(sanitizeText('  <script>alert(1)</script>Hello\u0000   world <b>!</b> '), 'alert(1)Hello world !');
  assert.equal(sanitizeText('a < b > c'), 'a c');
});
test('sanitizeText truncates and tolerates non-strings', () => {
  assert.equal(sanitizeText('x'.repeat(50), 10).length, 10);
  assert.equal(sanitizeText(undefined), '');
  assert.equal(sanitizeText(42), '');
});
test('escapeLike escapes wildcards', () => {
  assert.equal(escapeLike('50%_off\\'), '50\\%\\_off\\\\');
});

const good = { water: 5, covered: 4, gloves: 3, surroundings: 2, comment: ' ok <i>fine</i> ' };
test('validateReviewInput accepts valid input and cleans the comment', () => {
  assert.deepEqual(validateReviewInput(good), { water: 5, covered: 4, gloves: 3, surroundings: 2, comment: 'ok fine' });
});
test('validateReviewInput accepts numeric strings (HTML select values)', () => {
  assert.equal(validateReviewInput({ ...good, water: '5' }).water, 5);
});
test('validateReviewInput reports every invalid field', () => {
  try { validateReviewInput({ water: 0, covered: 6, gloves: 'x', surroundings: 2.5, comment: 5 }); assert.fail(); } catch (e) {
    assert.ok(e instanceof ValidationError);
    assert.deepEqual(e.details.map((d) => d.field).sort(), ['comment', 'covered', 'gloves', 'surroundings', 'water']);
  }
});
test('validateReviewInput rejects non-objects and bad photos', () => {
  for (const bad of [null, [], 'str', 5]) assert.throws(() => validateReviewInput(bad), ValidationError);
  assert.throws(() => validateReviewInput({ ...good, photo: 'http://evil/x.png' }), ValidationError);
  assert.throws(() => validateReviewInput({ ...good, photo: `data:image/png;base64,${'A'.repeat(200001)}` }), ValidationError);
  assert.equal(validateReviewInput({ ...good, photo: 'data:image/png;base64,AAAA' }).photo, 'data:image/png;base64,AAAA');
});
test('parseId / parseLimit / parseFilters', () => {
  assert.equal(parseId('7'), 7);
  for (const bad of ['0', '-1', '1.5', 'abc', '']) assert.throws(() => parseId(bad), ValidationError);
  assert.equal(parseLimit(null, 5, 20), 5);
  assert.equal(parseLimit('100', 5, 20), 20);
  assert.throws(() => parseLimit('x', 5, 20), ValidationError);
  assert.deepEqual(parseFilters(new URLSearchParams('q=%3Cb%3Edosa&area=Old%20City')), { q: 'dosa', area: 'Old City', specialty: '' });
});

test('logger writes JSON lines, honours level and child bindings', () => {
  const out = [];
  const log = createLogger({ level: 'warn', stream: { write: (l) => out.push(JSON.parse(l)) } }).child({ requestId: 'r1' });
  log.info('hidden');
  log.error('boom', { err: new Error('bad'), extra: 1 });
  assert.equal(out.length, 1);
  assert.equal(out[0].requestId, 'r1');
  assert.equal(out[0].err.message, 'bad');
  assert.equal(out[0].level, 'error');
});

test('config parses env with safe fallbacks', () => {
  const c = loadConfig({ PORT: 'abc', RATE_LIMIT_MAX: '-5', CORS_ORIGINS: 'http://a.test, http://b.test', TRUST_PROXY: 'true' });
  assert.equal(c.port, 3000);
  assert.equal(c.rateLimit.max, 120);
  assert.deepEqual(c.corsOrigins, ['http://a.test', 'http://b.test']);
  assert.equal(c.trustProxy, true);
  assert.throws(() => { c.port = 1; });
});
