'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startTestServer, post } = require('../testing/helpers');

const valid = { water: 5, covered: 5, gloves: 5, surroundings: 5, comment: 'Clean stall' };

test('GET /api/health reports ok with request id and security headers', async (t) => {
  const s = await startTestServer(); t.after(s.close);
  const res = await fetch(`${s.base}/api/health`);
  assert.equal(res.status, 200);
  assert.equal((await res.json()).status, 'ok');
  assert.match(res.headers.get('x-request-id'), /^[\w-]{8,64}$/);
  assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(res.headers.get('x-frame-options'), 'DENY');
  assert.match(res.headers.get('content-security-policy'), /default-src 'self'/);
  assert.equal(res.headers.get('cache-control'), 'no-store');
});

test('a valid incoming X-Request-Id is echoed; an invalid one is replaced', async (t) => {
  const s = await startTestServer(); t.after(s.close);
  const ok = await fetch(`${s.base}/api/health`, { headers: { 'x-request-id': 'trace-12345678' } });
  assert.equal(ok.headers.get('x-request-id'), 'trace-12345678');
  const bad = await fetch(`${s.base}/api/health`, { headers: { 'x-request-id': 'bad id!!' } });
  assert.notEqual(bad.headers.get('x-request-id'), 'bad id!!');
});

test('vendors: list, filter, search, and 404/400 handling', async (t) => {
  const s = await startTestServer(); t.after(s.close);
  const all = (await (await fetch(`${s.base}/api/vendors`)).json()).data;
  assert.equal(all.length, 6);
  assert.ok(all.every((v) => typeof v.hygiene.score === 'number'));
  const filtered = (await (await fetch(`${s.base}/api/vendors?area=Sindhi%20Colony&specialty=Pani%20Puri`)).json()).data;
  assert.deepEqual(filtered.map((v) => v.id), [1]);
  assert.equal((await (await fetch(`${s.base}/api/vendors?q=momos`)).json()).data.length, 1);
  assert.equal((await fetch(`${s.base}/api/vendors/1`)).status, 200);
  assert.equal((await fetch(`${s.base}/api/vendors/999`)).status, 404);
  const bad = await fetch(`${s.base}/api/vendors/abc`);
  assert.equal(bad.status, 400);
  assert.equal((await bad.json()).error.code, 'VALIDATION_ERROR');
});

test('trail and stats endpoints', async (t) => {
  const s = await startTestServer(); t.after(s.close);
  const trail = (await (await fetch(`${s.base}/api/trail?limit=2`)).json()).data;
  assert.equal(trail.length, 2);
  const stats = (await (await fetch(`${s.base}/api/stats`)).json()).data;
  assert.deepEqual(stats, { vendorCount: 6, reviewCount: 33, topScore: 4.8 });
  assert.equal((await fetch(`${s.base}/api/trail?limit=0`)).status, 400);
});

test('POST review: 201, score updates, comment is sanitised and listed', async (t) => {
  const s = await startTestServer(); t.after(s.close);
  const before = (await (await fetch(`${s.base}/api/vendors/5`)).json()).data.hygiene.score;
  const res = await post(`${s.base}/api/vendors/5/reviews`, { ...valid, comment: '<img src=x onerror=alert(1)>Spotless' });
  assert.equal(res.status, 201);
  const { data } = await res.json();
  assert.ok(data.vendor.hygiene.score > before);
  assert.equal(data.review.comment, 'Spotless');
  const list = (await (await fetch(`${s.base}/api/vendors/5/reviews?limit=1`)).json()).data;
  assert.equal(list[0].comment, 'Spotless');
});

test('POST review: validation errors list each bad field', async (t) => {
  const s = await startTestServer(); t.after(s.close);
  const res = await post(`${s.base}/api/vendors/1/reviews`, { water: 7, covered: 1 });
  assert.equal(res.status, 400);
  const body = await res.json();
  assert.deepEqual(body.error.details.map((d) => d.field).sort(), ['gloves', 'surroundings', 'water']);
  assert.ok(body.error.requestId);
});

test('POST review: unknown vendor 404, malformed JSON 400, wrong content type 415', async (t) => {
  const s = await startTestServer(); t.after(s.close);
  assert.equal((await post(`${s.base}/api/vendors/999/reviews`, valid)).status, 404);
  assert.equal((await post(`${s.base}/api/vendors/1/reviews`, '{not json')).status, 400);
  const res = await fetch(`${s.base}/api/vendors/1/reviews`, { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: 'hi' });
  assert.equal(res.status, 415);
});

test('POST review: oversized body is rejected with 413', async (t) => {
  const s = await startTestServer({ MAX_BODY_BYTES: '1000' }); t.after(s.close);
  const res = await post(`${s.base}/api/vendors/1/reviews`, { ...valid, comment: 'x'.repeat(5000) });
  assert.equal(res.status, 413);
  assert.equal((await res.json()).error.code, 'PAYLOAD_TOO_LARGE');
});

test('methods and routes: 405 for wrong method, 404 for unknown endpoint', async (t) => {
  const s = await startTestServer(); t.after(s.close);
  assert.equal((await fetch(`${s.base}/api/vendors`, { method: 'DELETE' })).status, 405);
  assert.equal((await fetch(`${s.base}/api/nope`)).status, 404);
});

test('rate limiting returns 429 with Retry-After once the limit is exceeded', async (t) => {
  const s = await startTestServer({ RATE_LIMIT_MAX: '3' }); t.after(s.close);
  const codes = [];
  let last;
  for (let i = 0; i < 5; i++) { last = await fetch(`${s.base}/api/health`); codes.push(last.status); }
  assert.deepEqual(codes, [200, 200, 200, 429, 429]);
  assert.ok(Number(last.headers.get('retry-after')) >= 1);
});

test('write requests have their own, stricter limit', async (t) => {
  const s = await startTestServer({ RATE_LIMIT_WRITE_MAX: '2' }); t.after(s.close);
  const codes = [];
  for (let i = 0; i < 3; i++) codes.push((await post(`${s.base}/api/vendors/1/reviews`, valid)).status);
  assert.deepEqual(codes, [201, 201, 429]);
  assert.equal((await fetch(`${s.base}/api/health`)).status, 200);
});

test('CORS: only allow-listed origins get headers; preflight answered', async (t) => {
  const s = await startTestServer({ CORS_ORIGINS: 'http://good.test' }); t.after(s.close);
  const good = await fetch(`${s.base}/api/health`, { headers: { Origin: 'http://good.test' } });
  assert.equal(good.headers.get('access-control-allow-origin'), 'http://good.test');
  const evil = await fetch(`${s.base}/api/health`, { headers: { Origin: 'http://evil.test' } });
  assert.equal(evil.headers.get('access-control-allow-origin'), null);
  const pre = await fetch(`${s.base}/api/vendors/1/reviews`, { method: 'OPTIONS', headers: { Origin: 'http://good.test' } });
  assert.equal(pre.status, 204);
  assert.match(pre.headers.get('access-control-allow-methods'), /POST/);
});

test('static files: index served, traversal and unknown files blocked', async (t) => {
  const s = await startTestServer(); t.after(s.close);
  const home = await fetch(`${s.base}/`);
  assert.equal(home.status, 200);
  assert.match(home.headers.get('content-type'), /text\/html/);
  assert.equal((await fetch(`${s.base}/missing.js`)).status, 404);
  assert.equal((await fetch(`${s.base}/..%2f..%2fpackage.json`)).status, 404);
  assert.equal((await fetch(`${s.base}/%2e%2e/package.json`)).status, 404);
  assert.equal((await fetch(`${s.base}/%00`)).status, 404);
  assert.equal((await fetch(`${s.base}/%E0%A4%A`)).status, 404);
  assert.equal((await fetch(`${s.base}/`, { method: 'HEAD' })).status, 200);
  assert.equal((await fetch(`${s.base}/`, { method: 'POST' })).status, 404);
});

test('unexpected failures return a generic 500 and are logged (no stack leak)', async (t) => {
  const s = await startTestServer({}, { logLevel: 'error' }); t.after(s.close);
  s.container.db.close();
  const res = await fetch(`${s.base}/api/vendors`);
  assert.equal(res.status, 500);
  const body = await res.json();
  assert.equal(body.error.code, 'INTERNAL_ERROR');
  assert.ok(!JSON.stringify(body).includes('node:sqlite'));
  assert.ok(s.logs.some((l) => JSON.parse(l).level === 'error'));
  const health = await fetch(`${s.base}/api/health`);
  assert.equal(health.status, 503);
});

test('access log line contains method, path, status and requestId', async (t) => {
  const s = await startTestServer({}, { logLevel: 'info' }); t.after(s.close);
  await fetch(`${s.base}/api/health`, { headers: { 'x-request-id': 'logtest-12345' } });
  await new Promise((r) => setTimeout(r, 20));
  const line = s.logs.map((l) => JSON.parse(l)).find((l) => l.msg === 'request');
  assert.equal(line.method, 'GET');
  assert.equal(line.path, '/api/health');
  assert.equal(line.status, 200);
  assert.equal(line.requestId, 'logtest-12345');
});
