'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadConfig } = require('../src/config');
const { openDatabase, withTransaction } = require('../src/db/database');
const { createContainer } = require('../src/container');
const { NotFoundError, ValidationError } = require('../src/errors');

const NOW = Date.parse('2026-01-01T00:00:00Z');
const make = () => createContainer(loadConfig({}), { db: openDatabase(':memory:'), clock: () => NOW });

test('vendor list includes computed hygiene; seeded top vendor is Mahalaxmi at 4.8', () => {
  const { services } = make();
  const all = services.vendors.list();
  assert.equal(all.length, 6);
  assert.equal(all.find((v) => v.id === 1).hygiene.score, 4.8);
});

test('get throws NotFoundError for unknown vendor', () => {
  const { services } = make();
  assert.throws(() => services.vendors.get(999), NotFoundError);
  assert.throws(() => services.vendors.recentReviews(999, 5), NotFoundError);
});

test('trail is the top-N vendors ordered by score', () => {
  const { services } = make();
  const trail = services.trail.top(3);
  assert.equal(trail.length, 3);
  assert.equal(trail[0].name, 'Mahalaxmi Chaat Center');
  assert.deepEqual(trail.map((t) => t.rank), [1, 2, 3]);
  assert.ok(trail[0].score >= trail[1].score && trail[1].score >= trail[2].score);
});

test('submitting a review changes the vendor score and the stats', () => {
  const { services } = make();
  const before = services.vendors.get(5).hygiene.score;
  const { review, vendor } = services.reviews.create(5, { water: 5, covered: 5, gloves: 5, surroundings: 5, comment: 'Much better now' });
  assert.ok(review.id > 0);
  assert.ok(vendor.hygiene.score > before);
  assert.equal(vendor.hygiene.reviewCount, 5);
  assert.equal(services.vendors.stats().reviewCount, 34);
});

test('review service validates input and vendor existence', () => {
  const { services } = make();
  assert.throws(() => services.reviews.create(1, { water: 9 }), ValidationError);
  assert.throws(() => services.reviews.create(999, { water: 5, covered: 5, gloves: 5, surroundings: 5 }), NotFoundError);
});

test('withTransaction rolls back when the callback throws', () => {
  const { db } = make();
  assert.throws(() => withTransaction(db, () => { db.exec("INSERT INTO vendors(id,name,area,specialty,dishes,price,hours,landmark,lat,lng) VALUES (99,'x','x','x','x','x','x','x',1,1)"); throw new Error('boom'); }));
  assert.equal(db.prepare('SELECT COUNT(*) n FROM vendors WHERE id = 99').get().n, 0);
});

test('health check passes on an open database', () => {
  assert.equal(make().services.health(), true);
});
