'use strict';
/** Composition root: the only place concrete classes are wired together (dependency injection). */
const { openDatabase } = require('./db/database');
const { seedIfEmpty } = require('./db/seed');
const { VendorRepository } = require('./repositories/vendorRepository');
const { ReviewRepository } = require('./repositories/reviewRepository');
const { HygieneService, TimeDecayStrategy } = require('./services/hygieneService');
const { VendorService } = require('./services/vendorService');
const { ReviewService } = require('./services/reviewService');
const { TrailService } = require('./services/trailService');

function createContainer(config, { clock = Date.now, db = openDatabase(config.dbPath) } = {}) {
  seedIfEmpty(db, clock());
  const vendorRepo = new VendorRepository(db);
  const reviewRepo = new ReviewRepository(db);
  const hygiene = new HygieneService({ strategy: new TimeDecayStrategy(config.halfLifeDays) });
  const vendors = new VendorService({ vendors: vendorRepo, reviews: reviewRepo, hygiene, clock });
  const reviews = new ReviewService({ vendors: vendorRepo, reviews: reviewRepo, vendorService: vendors, clock });
  const trail = new TrailService({ vendorService: vendors });
  const health = () => { db.prepare('SELECT 1 AS ok').get(); return true; };
  return { db, services: { vendors, reviews, trail, health }, close: () => db.close() };
}

module.exports = { createContainer };
