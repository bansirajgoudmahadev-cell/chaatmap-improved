'use strict';

const toReview = (r) => ({
  id: r.id, vendorId: r.vendor_id, water: r.water, covered: r.covered, gloves: r.gloves,
  surroundings: r.surroundings, comment: r.comment, photo: r.photo, createdAt: r.created_at,
});

/** Data access for reviews. */
class ReviewRepository {
  constructor(db) {
    this.db = db;
    this.insert = db.prepare(`INSERT INTO reviews (vendor_id,water,covered,gloves,surroundings,comment,photo,created_at)
      VALUES (?,?,?,?,?,?,?,?)`);
    this.recent = db.prepare('SELECT * FROM reviews WHERE vendor_id = ? ORDER BY created_at DESC, id DESC LIMIT ?');
    this.scoring = db.prepare('SELECT water,covered,gloves,surroundings,created_at FROM reviews WHERE vendor_id = ?');
    this.total = db.prepare('SELECT COUNT(*) AS n FROM reviews');
  }

  add({ vendorId, water, covered, gloves, surroundings, comment = '', photo = null, createdAt }) {
    const { lastInsertRowid } = this.insert.run(vendorId, water, covered, gloves, surroundings, comment, photo, createdAt);
    return { id: Number(lastInsertRowid), vendorId, water, covered, gloves, surroundings, comment, photo, createdAt };
  }

  recentForVendor(vendorId, limit = 5) {
    return this.recent.all(vendorId, limit).map(toReview);
  }

  /** Rows needed for scoring (no photos) for many vendors in one query -> Map(vendorId -> rows). */
  scoringRowsFor(vendorIds) {
    const map = new Map();
    if (!vendorIds.length) return map;
    const marks = vendorIds.map(() => '?').join(',');
    const rows = this.db.prepare(
      `SELECT vendor_id,water,covered,gloves,surroundings,created_at FROM reviews WHERE vendor_id IN (${marks})`,
    ).all(...vendorIds);
    for (const r of rows) {
      if (!map.has(r.vendor_id)) map.set(r.vendor_id, []);
      map.get(r.vendor_id).push(r);
    }
    return map;
  }

  count() { return this.total.get().n; }
}

module.exports = { ReviewRepository };
