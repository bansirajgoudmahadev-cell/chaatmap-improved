'use strict';
const { escapeLike } = require('../utils/sanitize');

const toVendor = (r) => ({
  id: r.id, name: r.name, area: r.area, specialty: r.specialty, dishes: r.dishes, price: r.price,
  hours: r.hours, landmark: r.landmark, lat: r.lat, lng: r.lng, fssai: r.fssai === 1, open: r.is_open === 1,
});

/** Data access for vendors. All values are bound parameters; SQL text is built only from fixed fragments. */
class VendorRepository {
  constructor(db) {
    this.db = db;
    this.byId = db.prepare('SELECT * FROM vendors WHERE id = ?');
  }

  findById(id) {
    const row = this.byId.get(id);
    return row ? toVendor(row) : null;
  }

  search({ q = '', area = '', specialty = '' } = {}) {
    const where = [];
    const params = [];
    if (area) { where.push('area = ?'); params.push(area); }
    if (specialty) { where.push('specialty = ?'); params.push(specialty); }
    if (q) {
      where.push("(name LIKE ? ESCAPE '\\' OR dishes LIKE ? ESCAPE '\\' OR specialty LIKE ? ESCAPE '\\' OR area LIKE ? ESCAPE '\\')");
      const like = `%${escapeLike(q)}%`;
      params.push(like, like, like, like);
    }
    const sql = `SELECT * FROM vendors${where.length ? ` WHERE ${where.join(' AND ')}` : ''} ORDER BY name`;
    return this.db.prepare(sql).all(...params).map(toVendor);
  }
}

module.exports = { VendorRepository };
