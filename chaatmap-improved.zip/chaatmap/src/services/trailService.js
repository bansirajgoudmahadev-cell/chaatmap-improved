'use strict';

/** Builds the "top hygiene food trail": best-scored vendors, ties broken by trust then name. */
class TrailService {
  constructor({ vendorService }) { this.vendorService = vendorService; }

  top(limit = 3) {
    return this.vendorService.list()
      .filter((v) => v.hygiene.score != null)
      .sort((a, b) => b.hygiene.score - a.hygiene.score || b.hygiene.trust - a.hygiene.trust || a.name.localeCompare(b.name))
      .slice(0, limit)
      .map((v, i) => ({ rank: i + 1, id: v.id, name: v.name, area: v.area, specialty: v.specialty, score: v.hygiene.score, trust: v.hygiene.trust }));
  }
}

module.exports = { TrailService };
