'use strict';
const { NotFoundError } = require('../errors');
const { validateReviewInput } = require('../utils/validate');

/** Validates and stores a review, then returns the vendor's refreshed hygiene assessment. */
class ReviewService {
  constructor({ vendors, reviews, vendorService, clock = Date.now }) {
    Object.assign(this, { vendors, reviews, vendorService, clock });
  }

  create(vendorId, body) {
    const input = validateReviewInput(body);
    if (!this.vendors.findById(vendorId)) throw new NotFoundError('Vendor');
    const review = this.reviews.add({ vendorId, ...input, createdAt: new Date(this.clock()).toISOString() });
    return { review, vendor: this.vendorService.get(vendorId) };
  }
}

module.exports = { ReviewService };
