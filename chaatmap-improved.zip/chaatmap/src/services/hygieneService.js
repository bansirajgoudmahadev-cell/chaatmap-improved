'use strict';
/**
 * Hygiene scoring.
 *
 * Strategy pattern: a "weighing strategy" decides how much each review counts.
 *  - FlatStrategy      every review counts equally (the original behaviour)
 *  - TimeDecayStrategy newer reviews count more (half-life in days)
 * The factor weights (water 40%, covered 25%, gloves 20%, surroundings 15%) are injected and validated.
 */
const DAY_MS = 86400000;
const FACTOR_KEYS = ['water', 'covered', 'gloves', 'surroundings'];
const DEFAULT_WEIGHTS = Object.freeze({ water: 0.4, covered: 0.25, gloves: 0.2, surroundings: 0.15 });

class FlatStrategy {
  weigh() { return 1; }
}

class TimeDecayStrategy {
  constructor(halfLifeDays = 45) {
    if (!(halfLifeDays > 0)) throw new RangeError('halfLifeDays must be > 0');
    this.halfLifeDays = halfLifeDays;
  }

  weigh(review, nowMs) {
    const ageDays = Math.max(0, (nowMs - Date.parse(review.created_at)) / DAY_MS);
    return Math.max(2 ** (-ageDays / this.halfLifeDays), 1e-9);
  }
}

const round2 = (n) => Math.round(n * 100) / 100;

function gradeFor(score) {
  if (score == null) return 'Unrated';
  if (score >= 4.5) return 'Excellent';
  if (score >= 3.5) return 'Good';
  if (score >= 2.5) return 'Fair';
  return 'Poor';
}

class HygieneService {
  constructor({ strategy = new TimeDecayStrategy(), weights = DEFAULT_WEIGHTS } = {}) {
    const sum = FACTOR_KEYS.reduce((s, k) => s + (weights[k] ?? NaN), 0);
    if (!(Math.abs(sum - 1) < 1e-9)) throw new RangeError('Factor weights must sum to 1');
    this.strategy = strategy;
    this.weights = weights;
  }

  /**
   * @param {Array} reviews rows with water/covered/gloves/surroundings/created_at
   * @returns {{score:number|null, grade:string, trust:number, reviewCount:number, factors:object}}
   */
  assess(reviews, nowMs = Date.now()) {
    const n = reviews.length;
    if (!n) return { score: null, grade: 'Unrated', trust: 0, reviewCount: 0, factors: Object.fromEntries(FACTOR_KEYS.map((k) => [k, null])) };

    let totalWeight = 0;
    const sums = Object.fromEntries(FACTOR_KEYS.map((k) => [k, 0]));
    for (const r of reviews) {
      const w = this.strategy.weigh(r, nowMs);
      totalWeight += w;
      for (const k of FACTOR_KEYS) sums[k] += r[k] * w;
    }
    const means = Object.fromEntries(FACTOR_KEYS.map((k) => [k, sums[k] / totalWeight]));
    const score = round2(FACTOR_KEYS.reduce((s, k) => s + this.weights[k] * means[k], 0));

    // Trust (0-100): more reviews => more trust (saturating); stale reviews pull it down.
    const volume = 1 - Math.exp(-n / 5);
    const recency = totalWeight / n;
    const trust = Math.round(100 * volume * (0.4 + 0.6 * recency));

    return {
      score, grade: gradeFor(score), trust, reviewCount: n,
      factors: Object.fromEntries(FACTOR_KEYS.map((k) => [k, round2(means[k])])),
    };
  }
}

module.exports = { HygieneService, FlatStrategy, TimeDecayStrategy, DEFAULT_WEIGHTS, gradeFor };
