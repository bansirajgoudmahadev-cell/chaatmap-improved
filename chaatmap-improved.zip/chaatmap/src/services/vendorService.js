'use strict';
const { NotFoundError } = require('../errors');

/** Combines vendor records with their computed hygiene assessment. */
class VendorService {
  constructor({ vendors, reviews, hygiene, clock = Date.now }) {
    Object.assign(this, { vendors, reviews, hygiene, clock });
  }

  list(filters = {}) {
    const found = this.vendors.search(filters);
    const rows = this.reviews.scoringRowsFor(found.map((v) => v.id));
    const now = this.clock();
    return found.map((v) => ({ ...v, hygiene: this.hygiene.assess(rows.get(v.id) ?? [], now) }));
  }

  get(id) {
    const vendor = this.vendors.findById(id);
    if (!vendor) throw new NotFoundError('Vendor');
    const rows = this.reviews.scoringRowsFor([id]).get(id) ?? [];
    return { ...vendor, hygiene: this.hygiene.assess(rows, this.clock()) };
  }

  recentReviews(id, limit) {
    this.get(id); // 404 if the vendor does not exist
    return this.reviews.recentForVendor(id, limit);
  }

  stats() {
    const all = this.list();
    const scores = all.map((v) => v.hygiene.score).filter((s) => s != null);
    return { vendorCount: all.length, reviewCount: this.reviews.count(), topScore: scores.length ? Math.max(...scores) : null };
  }
}

module.exports = { VendorService };
