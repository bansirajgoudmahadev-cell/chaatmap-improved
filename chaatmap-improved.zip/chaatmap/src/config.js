'use strict';
const path = require('node:path');

const posInt = (value, fallback) => {
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) && n > 0 ? n : fallback;
};

/** Reads configuration from the environment once; the result is immutable. */
function loadConfig(env = process.env) {
  const root = path.join(__dirname, '..');
  return Object.freeze({
    env: env.NODE_ENV || 'development',
    port: env.PORT === '0' ? 0 : posInt(env.PORT, 3000),
    host: env.HOST || '127.0.0.1',
    dbPath: env.DB_PATH ? path.resolve(env.DB_PATH) : path.join(root, 'data', 'chaatmap.db'),
    publicDir: path.join(root, 'public'),
    logLevel: env.LOG_LEVEL || 'info',
    corsOrigins: (env.CORS_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean),
    trustProxy: env.TRUST_PROXY === 'true',
    halfLifeDays: posInt(env.DECAY_HALF_LIFE_DAYS, 45),
    maxBodyBytes: posInt(env.MAX_BODY_BYTES, 300000),
    rateLimit: Object.freeze({
      windowMs: posInt(env.RATE_LIMIT_WINDOW_MS, 60000),
      max: posInt(env.RATE_LIMIT_MAX, 120),
      writeMax: posInt(env.RATE_LIMIT_WRITE_MAX, 10),
    }),
  });
}

module.exports = { loadConfig };
