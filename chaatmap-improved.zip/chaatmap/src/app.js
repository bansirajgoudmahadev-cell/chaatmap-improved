'use strict';
const { randomUUID } = require('node:crypto');
const { AppError, NotFoundError, RateLimitError, ValidationError } = require('./errors');
const { RateLimiter } = require('./http/rateLimiter');
const { buildRouter } = require('./http/routes');
const { applySecurityHeaders, applyCors, clientIp, readJsonBody, serveStatic } = require('./http/middleware');

function sendJson(res, status, body) {
  if (res.headersSent) return;
  const payload = JSON.stringify(body);
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Content-Length', Buffer.byteLength(payload));
  res.setHeader('Cache-Control', 'no-store');
  res.end(payload);
}

/** Central error handler: known errors keep their status; anything else is logged and hidden behind a 500. */
function handleError(err, res, log, requestId) {
  if (err instanceof AppError) {
    if (err.retryAfterSec) res.setHeader('Retry-After', err.retryAfterSec);
    if (err.status === 413) res.setHeader('Connection', 'close');
    log.warn('request rejected', { status: err.status, code: err.code });
    return sendJson(res, err.status, { error: { code: err.code, message: err.message, details: err.details, requestId } });
  }
  log.error('unhandled error', { err });
  return sendJson(res, 500, { error: { code: 'INTERNAL_ERROR', message: 'Something went wrong', requestId } });
}

/** Builds the request handler (pure function of its dependencies, so it can be tested without a network). */
function createApp({ services, config, logger, clock = Date.now }) {
  const router = buildRouter(services);
  const limiter = new RateLimiter({ windowMs: config.rateLimit.windowMs, clock });

  return async function handle(req, res) {
    const incoming = req.headers['x-request-id'];
    const requestId = typeof incoming === 'string' && /^[\w-]{8,64}$/.test(incoming) ? incoming : randomUUID();
    const log = logger.child({ requestId });
    const started = process.hrtime.bigint();
    res.setHeader('X-Request-Id', requestId);
    applySecurityHeaders(res);
    res.on('finish', () => log.info('request', {
      method: req.method, path: (req.url || '').split('?')[0], status: res.statusCode,
      ms: Number((process.hrtime.bigint() - started) / 1000000n),
    }));

    try {
      if (applyCors(req, res, config.corsOrigins)) return;
      let url;
      try { url = new URL(req.url, 'http://localhost'); } catch { throw new ValidationError([{ field: 'url', message: 'Malformed URL' }]); }

      if (!url.pathname.startsWith('/api/')) return await serveStatic(req, res, url.pathname, config.publicDir);

      const ip = clientIp(req, config.trustProxy);
      const isWrite = req.method !== 'GET' && req.method !== 'HEAD';
      const verdict = limiter.consume(isWrite ? `${ip}:w` : ip, isWrite ? config.rateLimit.writeMax : config.rateLimit.max);
      res.setHeader('X-RateLimit-Remaining', verdict.remaining);
      if (!verdict.allowed) throw new RateLimitError(verdict.retryAfterSec);

      const match = router.match(req.method, url.pathname);
      if (!match) throw new NotFoundError('Endpoint');
      if (match.methodNotAllowed) throw new AppError(405, 'METHOD_NOT_ALLOWED', 'Method not allowed');

      const body = req.method === 'POST' ? await readJsonBody(req, config.maxBodyBytes) : undefined;
      const result = match.handler({ params: match.params, query: url.searchParams, body, req });
      sendJson(res, result.status, result.body);
    } catch (err) {
      handleError(err, res, log, requestId);
    }
  };
}

module.exports = { createApp };
