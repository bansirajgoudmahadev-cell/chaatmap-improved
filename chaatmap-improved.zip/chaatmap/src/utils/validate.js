'use strict';
const { ValidationError } = require('../errors');
const { sanitizeText } = require('./sanitize');

const FACTORS = ['water', 'covered', 'gloves', 'surroundings'];
const PHOTO_RE = /^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/;
const MAX_PHOTO_CHARS = 200000;

/** Validates and normalises a review payload. Throws ValidationError listing every problem. */
function validateReviewInput(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw new ValidationError([{ field: 'body', message: 'JSON object required' }]);
  }
  const errors = [];
  const out = {};
  for (const f of FACTORS) {
    const raw = body[f];
    const n = typeof raw === 'string' && raw.trim() !== '' ? Number(raw) : raw;
    if (!Number.isInteger(n) || n < 1 || n > 5) errors.push({ field: f, message: 'must be an integer from 1 to 5' });
    else out[f] = n;
  }
  if (body.comment != null && typeof body.comment !== 'string') {
    errors.push({ field: 'comment', message: 'must be text' });
  } else {
    out.comment = sanitizeText(body.comment ?? '', 300);
  }
  if (body.photo != null && body.photo !== '') {
    if (typeof body.photo !== 'string' || body.photo.length > MAX_PHOTO_CHARS || !PHOTO_RE.test(body.photo)) {
      errors.push({ field: 'photo', message: 'must be a jpeg/png/webp data URL under 200 KB' });
    } else out.photo = body.photo;
  }
  if (errors.length) throw new ValidationError(errors);
  return out;
}

function parseId(raw) {
  const n = Number(raw);
  if (!Number.isInteger(n) || n < 1) throw new ValidationError([{ field: 'id', message: 'must be a positive integer' }]);
  return n;
}

function parseLimit(raw, fallback, max) {
  if (raw == null || raw === '') return fallback;
  const n = Number(raw);
  if (!Number.isInteger(n) || n < 1) throw new ValidationError([{ field: 'limit', message: 'must be a positive integer' }]);
  return Math.min(n, max);
}

function parseFilters(params) {
  return {
    q: sanitizeText(params.get('q') ?? '', 60),
    area: sanitizeText(params.get('area') ?? '', 60),
    specialty: sanitizeText(params.get('specialty') ?? '', 60),
  };
}

module.exports = { FACTORS, validateReviewInput, parseId, parseLimit, parseFilters };
