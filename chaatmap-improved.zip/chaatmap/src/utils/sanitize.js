'use strict';

/** Strips markup, control/bidi characters and extra whitespace, then truncates. Output is plain text. */
function sanitizeText(input, maxLen = 500) {
  if (typeof input !== 'string') return '';
  return input
    .normalize('NFKC')
    .replace(/<[^>]*>/g, '')
    .replace(/[<>]/g, '')
    .replace(/[\u0000-\u001F\u007F-\u009F\u200B-\u200F\u202A-\u202E\u2066-\u2069]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, maxLen);
}

/** Escapes LIKE wildcards so user input is matched literally (use with ESCAPE '\'). */
const escapeLike = (s) => s.replace(/[\\%_]/g, '\\$&');

module.exports = { sanitizeText, escapeLike };
