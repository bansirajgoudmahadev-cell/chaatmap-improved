'use strict';
/** Typed application errors. The error handler maps them to HTTP responses. */
class AppError extends Error {
  constructor(status, code, message, details) {
    super(message);
    this.name = this.constructor.name;
    this.status = status;
    this.code = code;
    this.details = details;
  }
}
class ValidationError extends AppError {
  constructor(details = [], message = 'Invalid input') { super(400, 'VALIDATION_ERROR', message, details); }
}
class NotFoundError extends AppError {
  constructor(what = 'Resource') { super(404, 'NOT_FOUND', `${what} not found`); }
}
class PayloadTooLargeError extends AppError {
  constructor() { super(413, 'PAYLOAD_TOO_LARGE', 'Request body is too large'); }
}
class UnsupportedMediaTypeError extends AppError {
  constructor() { super(415, 'UNSUPPORTED_MEDIA_TYPE', 'Content-Type must be application/json'); }
}
class RateLimitError extends AppError {
  constructor(retryAfterSec) {
    super(429, 'RATE_LIMITED', 'Too many requests, please slow down');
    this.retryAfterSec = retryAfterSec;
  }
}

module.exports = { AppError, ValidationError, NotFoundError, PayloadTooLargeError, UnsupportedMediaTypeError, RateLimitError };
