'use strict';
const http = require('node:http');
const { loadConfig } = require('./config');
const { createLogger } = require('./logger');
const { createContainer } = require('./container');
const { createApp } = require('./app');

/** Creates (but does not start listening on) the HTTP server. Used by main() and by the tests. */
function createServer(config, { logger = createLogger({ level: config.logLevel }), clock, db } = {}) {
  const container = createContainer(config, { clock, db });
  const server = http.createServer(createApp({ services: container.services, config, logger, clock }));
  server.requestTimeout = 15000;
  server.headersTimeout = 10000;
  server.keepAliveTimeout = 5000;
  return { server, container, logger };
}

function main() {
  try { process.loadEnvFile(); } catch { /* .env is optional */ }
  const config = loadConfig();
  const { server, container, logger } = createServer(config);

  let closing = false;
  const shutdown = (reason, code = 0) => {
    if (closing) return;
    closing = true;
    logger.info('shutting down', { reason });
    setTimeout(() => process.exit(1), 10000).unref();
    server.close(() => { container.close(); process.exit(code); });
    server.closeIdleConnections();
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('uncaughtException', (err) => { logger.error('uncaught exception', { err }); shutdown('uncaughtException', 1); });
  process.on('unhandledRejection', (err) => { logger.error('unhandled rejection', { err }); shutdown('unhandledRejection', 1); });

  server.listen(config.port, config.host, () => {
    logger.info('ChaatMap listening', { url: `http://${config.host}:${server.address().port}`, env: config.env });
  });
}

if (require.main === module) main();

module.exports = { createServer };
