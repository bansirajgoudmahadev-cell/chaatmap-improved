'use strict';
/** Minimal structured (JSON-lines) logger with levels and child loggers. */
const LEVELS = { debug: 10, info: 20, warn: 30, error: 40, silent: 99 };

function serializeError(err) {
  if (!(err instanceof Error)) return { message: String(err) };
  return { name: err.name, message: err.message, code: err.code, stack: err.stack };
}

function createLogger({ level = 'info', stream = process.stdout, base = {} } = {}) {
  const threshold = LEVELS[level] ?? LEVELS.info;
  const write = (lvl, msg, fields = {}) => {
    if (LEVELS[lvl] < threshold) return;
    const { err, ...rest } = fields;
    const line = { time: new Date().toISOString(), level: lvl, msg, ...base, ...rest };
    if (err) line.err = serializeError(err);
    stream.write(`${JSON.stringify(line)}\n`);
  };
  return {
    debug: (m, f) => write('debug', m, f),
    info: (m, f) => write('info', m, f),
    warn: (m, f) => write('warn', m, f),
    error: (m, f) => write('error', m, f),
    child: (extra) => createLogger({ level, stream, base: { ...base, ...extra } }),
  };
}

module.exports = { createLogger, LEVELS };
