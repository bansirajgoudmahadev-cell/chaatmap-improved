'use strict';
const { Router } = require('./router');
const { parseId, parseLimit, parseFilters } = require('../utils/validate');

/** Maps URLs to service calls. Handlers return { status, body }; they never touch req/res directly. */
function buildRouter({ vendors, reviews, trail, health }, { startedAt = Date.now() } = {}) {
  const r = new Router();
  r.add('GET', '/api/health', () => {
    try { health(); } catch { return { status: 503, body: { status: 'degraded', db: 'down' } }; }
    return { status: 200, body: { status: 'ok', db: 'up', uptimeSec: Math.round((Date.now() - startedAt) / 1000) } };
  });
  r.add('GET', '/api/stats', () => ({ status: 200, body: { data: vendors.stats() } }));
  r.add('GET', '/api/vendors', ({ query }) => ({ status: 200, body: { data: vendors.list(parseFilters(query)) } }));
  r.add('GET', '/api/vendors/:id', ({ params }) => ({ status: 200, body: { data: vendors.get(parseId(params.id)) } }));
  r.add('GET', '/api/vendors/:id/reviews', ({ params, query }) => ({
    status: 200,
    body: { data: vendors.recentReviews(parseId(params.id), parseLimit(query.get('limit'), 5, 20)) },
  }));
  r.add('POST', '/api/vendors/:id/reviews', ({ params, body }) => ({
    status: 201, body: { data: reviews.create(parseId(params.id), body) },
  }));
  r.add('GET', '/api/trail', ({ query }) => ({ status: 200, body: { data: trail.top(parseLimit(query.get('limit'), 3, 10)) } }));
  return r;
}

module.exports = { buildRouter };
