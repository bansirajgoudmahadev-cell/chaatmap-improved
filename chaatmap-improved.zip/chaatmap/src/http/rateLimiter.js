'use strict';
/** Fixed-window, in-memory rate limiter keyed by caller (suitable for a single instance). */
class RateLimiter {
  constructor({ windowMs, clock = Date.now }) {
    this.windowMs = windowMs;
    this.clock = clock;
    this.hits = new Map();
  }

  /** @returns {{allowed:boolean, remaining:number, retryAfterSec:number}} */
  consume(key, max) {
    const now = this.clock();
    if (this.hits.size > 5000) this.sweep(now);
    let entry = this.hits.get(key);
    if (!entry || entry.resetAt <= now) {
      entry = { count: 0, resetAt: now + this.windowMs };
      this.hits.set(key, entry);
    }
    entry.count += 1;
    return {
      allowed: entry.count <= max,
      remaining: Math.max(0, max - entry.count),
      retryAfterSec: Math.max(1, Math.ceil((entry.resetAt - now) / 1000)),
    };
  }

  sweep(now = this.clock()) {
    for (const [k, v] of this.hits) if (v.resetAt <= now) this.hits.delete(k);
  }
}

module.exports = { RateLimiter };
