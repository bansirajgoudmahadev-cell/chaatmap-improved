'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { ValidationError, PayloadTooLargeError, UnsupportedMediaTypeError, NotFoundError } = require('../errors');

const CSP = [
  "default-src 'self'",
  "script-src 'self' https://unpkg.com",
  "style-src 'self' https://unpkg.com",
  "img-src 'self' data: blob: https://unpkg.com https://*.tile.openstreetmap.org",
  "connect-src 'self'",
  "worker-src 'self'",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "frame-ancestors 'none'",
].join('; ');

function applySecurityHeaders(res) {
  res.setHeader('Content-Security-Policy', CSP);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
}

/** Allow-list CORS. Returns true when the request was a preflight that has been fully answered. */
function applyCors(req, res, allowedOrigins) {
  const origin = req.headers.origin;
  const allowed = origin && allowedOrigins.includes(origin);
  if (allowed) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
  }
  if (req.method === 'OPTIONS') {
    if (allowed) {
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
      res.setHeader('Access-Control-Max-Age', '600');
    }
    res.statusCode = 204;
    res.end();
    return true;
  }
  return false;
}

function clientIp(req, trustProxy) {
  if (trustProxy) {
    const fwd = req.headers['x-forwarded-for'];
    if (typeof fwd === 'string' && fwd) return fwd.split(',')[0].trim();
  }
  return req.socket.remoteAddress || 'unknown';
}

/** Reads and parses a JSON body with a hard size limit. */
function readJsonBody(req, maxBytes) {
  const type = String(req.headers['content-type'] || '');
  if (!type.toLowerCase().startsWith('application/json')) throw new UnsupportedMediaTypeError();
  if (Number(req.headers['content-length']) > maxBytes) throw new PayloadTooLargeError();
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > maxBytes) { chunks.length = 0; reject(new PayloadTooLargeError()); req.pause(); return; }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (size > maxBytes) return;
      const text = Buffer.concat(chunks).toString('utf8');
      if (!text.trim()) return resolve({});
      try { resolve(JSON.parse(text)); } catch { reject(new ValidationError([{ field: 'body', message: 'Malformed JSON' }])); }
    });
    req.on('error', reject);
  });
}

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8',
};

/** Serves files from publicDir only; rejects traversal and null bytes. */
async function serveStatic(req, res, pathname, publicDir) {
  if (req.method !== 'GET' && req.method !== 'HEAD') throw new NotFoundError('Page');
  let rel;
  try { rel = decodeURIComponent(pathname); } catch { throw new NotFoundError('Page'); }
  if (rel.includes('\0')) throw new NotFoundError('Page');
  const root = path.resolve(publicDir);
  const file = path.resolve(root, `.${rel === '/' ? '/index.html' : rel}`);
  if (file !== root && !file.startsWith(root + path.sep)) throw new NotFoundError('Page');
  let stat;
  try { stat = await fs.promises.stat(file); } catch { throw new NotFoundError('Page'); }
  if (!stat.isFile()) throw new NotFoundError('Page');
  const ext = path.extname(file).toLowerCase();
  res.statusCode = 200;
  res.setHeader('Content-Type', MIME[ext] || 'application/octet-stream');
  res.setHeader('Content-Length', stat.size);
  res.setHeader('Cache-Control', ext === '.html' || path.basename(file) === 'sw.js' ? 'no-cache' : 'public, max-age=300');
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file).pipe(res);
}

module.exports = { applySecurityHeaders, applyCors, clientIp, readJsonBody, serveStatic, CSP };
