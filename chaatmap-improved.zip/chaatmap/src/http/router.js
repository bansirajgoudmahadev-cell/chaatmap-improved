'use strict';
/** Tiny router: ':name' segments become params. Distinguishes 404 (no path) from 405 (wrong method). */
class Router {
  constructor() { this.routes = []; }

  add(method, pattern, handler) {
    const keys = [];
    const source = pattern.replace(/:([A-Za-z]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; });
    this.routes.push({ method, re: new RegExp(`^${source}/?$`), keys, handler });
    return this;
  }

  match(method, pathname) {
    let pathMatched = false;
    for (const r of this.routes) {
      const m = r.re.exec(pathname);
      if (!m) continue;
      pathMatched = true;
      if (r.method !== method) continue;
      const params = Object.fromEntries(r.keys.map((k, i) => [k, m[i + 1]]));
      return { handler: r.handler, params };
    }
    return pathMatched ? { methodNotAllowed: true } : null;
  }
}

module.exports = { Router };
