'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS vendors (
  id        INTEGER PRIMARY KEY,
  name      TEXT NOT NULL,
  area      TEXT NOT NULL,
  specialty TEXT NOT NULL,
  dishes    TEXT NOT NULL,
  price     TEXT NOT NULL,
  hours     TEXT NOT NULL,
  landmark  TEXT NOT NULL,
  lat       REAL NOT NULL CHECK (lat BETWEEN -90 AND 90),
  lng       REAL NOT NULL CHECK (lng BETWEEN -180 AND 180),
  fssai     INTEGER NOT NULL DEFAULT 0 CHECK (fssai IN (0, 1)),
  is_open   INTEGER NOT NULL DEFAULT 1 CHECK (is_open IN (0, 1))
);
CREATE TABLE IF NOT EXISTS reviews (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  vendor_id  INTEGER NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
  water      INTEGER NOT NULL CHECK (water BETWEEN 1 AND 5),
  covered    INTEGER NOT NULL CHECK (covered BETWEEN 1 AND 5),
  gloves     INTEGER NOT NULL CHECK (gloves BETWEEN 1 AND 5),
  surroundings INTEGER NOT NULL CHECK (surroundings BETWEEN 1 AND 5),
  comment    TEXT NOT NULL DEFAULT '',
  photo      TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_vendors_locality ON vendors(area, specialty);
CREATE INDEX IF NOT EXISTS idx_reviews_vendor   ON reviews(vendor_id, created_at);
`;

/** Opens SQLite in WAL mode with foreign keys enforced and applies the schema. */
function openDatabase(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000; PRAGMA synchronous = NORMAL;');
  db.exec(SCHEMA);
  return db;
}

/** Runs fn inside a transaction; rolls back if it throws. */
function withTransaction(db, fn) {
  db.exec('BEGIN');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

module.exports = { openDatabase, withTransaction };
