'use strict';
const { withTransaction } = require('./database');

/* Demo data. Coordinates are illustrative Hyderabad positions; FSSAI flags are sample labels only. */
const SEED_VENDORS = [
  { id: 1, name: 'Mahalaxmi Chaat Center', area: 'Sindhi Colony', specialty: 'Pani Puri', dishes: 'Pani Puri, Aloo Tikki, Dahi Puri', price: '₹30–₹80', hours: '4:00 PM – 10:00 PM', lat: 17.4435, lng: 78.4983, landmark: 'Near Sindhi Colony main road', fssai: 1, is_open: 1, f: [5, 5, 4, 5], reviews: 8 },
  { id: 2, name: 'Raju Dosa Point', area: 'Secunderabad', specialty: 'Dosa', dishes: 'Masala Dosa, Onion Dosa', price: '₹40–₹90', hours: '7:00 AM – 11:00 AM', lat: 17.4399, lng: 78.4983, landmark: 'Near station road', fssai: 0, is_open: 1, f: [4, 4, 4, 4], reviews: 6 },
  { id: 3, name: 'Old City Chaat Corner', area: 'Old City', specialty: 'Chaat', dishes: 'Papdi Chaat, Samosa Chaat', price: '₹30–₹70', hours: '5:00 PM – 10:30 PM', lat: 17.3616, lng: 78.4747, landmark: 'Near Charminar approach road', fssai: 1, is_open: 1, f: [4, 5, 3, 4], reviews: 7 },
  { id: 4, name: 'Madhapur Momos Hub', area: 'Madhapur', specialty: 'Momos', dishes: 'Veg Momos, Fried Momos', price: '₹60–₹120', hours: '5:00 PM – 11:00 PM', lat: 17.4483, lng: 78.3915, landmark: 'Near Madhapur metro', fssai: 0, is_open: 1, f: [4, 4, 5, 4], reviews: 5 },
  { id: 5, name: 'Lakshmi Pav Bhaji Stall', area: 'Charminar', specialty: 'Pav Bhaji', dishes: 'Pav Bhaji, Tawa Pulao', price: '₹50–₹100', hours: '6:00 PM – 11:00 PM', lat: 17.361, lng: 78.476, landmark: 'Near Laad Bazaar', fssai: 0, is_open: 0, f: [3, 4, 3, 4], reviews: 4 },
  { id: 6, name: 'Sai Mirchi Bajji', area: 'Sindhi Colony', specialty: 'Mirchi Bajji', dishes: 'Mirchi Bajji, Punugulu', price: '₹20–₹50', hours: '4:30 PM – 9:30 PM', lat: 17.446, lng: 78.501, landmark: 'Near community park', fssai: 0, is_open: 1, f: [4, 4, 4, 3], reviews: 3 },
];

const DAY_MS = 86400000;

/** Inserts demo vendors plus synthetic seed reviews, only when the database is empty. */
function seedIfEmpty(db, nowMs = Date.now()) {
  if (db.prepare('SELECT COUNT(*) AS n FROM vendors').get().n > 0) return false;
  const addVendor = db.prepare(`INSERT INTO vendors (id,name,area,specialty,dishes,price,hours,landmark,lat,lng,fssai,is_open)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`);
  const addReview = db.prepare(`INSERT INTO reviews (vendor_id,water,covered,gloves,surroundings,comment,created_at)
    VALUES (?,?,?,?,?,?,?)`);
  withTransaction(db, () => {
    for (const v of SEED_VENDORS) {
      addVendor.run(v.id, v.name, v.area, v.specialty, v.dishes, v.price, v.hours, v.landmark, v.lat, v.lng, v.fssai, v.is_open);
      for (let i = 0; i < v.reviews; i++) {
        const at = new Date(nowMs - (i * 6 + 1) * DAY_MS).toISOString();
        addReview.run(v.id, v.f[0], v.f[1], v.f[2], v.f[3], 'Seed review (demo data)', at);
      }
    }
  });
  return true;
}

module.exports = { seedIfEmpty, SEED_VENDORS };
