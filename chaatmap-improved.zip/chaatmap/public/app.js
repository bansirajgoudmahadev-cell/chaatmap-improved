'use strict';
(() => {
  const $ = (id) => document.getElementById(id);
  const LS = { trail: 'chaatmap_trail_v2', vendors: 'chaatmap_vendors_v2', stats: 'chaatmap_stats_v2', queue: 'chaatmap_queue_v2' };
  const state = { all: [], view: [], selectedId: null, offline: false };
  let map = null;
  const markers = new Map();
  let debounce;

  /* ---------- helpers ---------- */
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const readLS = (k, fallback) => { try { return JSON.parse(localStorage.getItem(k)) ?? fallback; } catch { return fallback; } };
  const writeLS = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage full or blocked */ } };
  const stars = (n) => '★'.repeat(Math.round(n)) + '☆'.repeat(5 - Math.round(n));
  const fmtScore = (s) => (s == null ? '—' : s.toFixed(1));
  function toast(msg) {
    const t = $('toast'); t.textContent = msg; t.hidden = false;
    clearTimeout(toast.id); toast.id = setTimeout(() => { t.hidden = true; }, 3500);
  }
  function setOffline(off) {
    state.offline = off;
    const el = $('netStatus');
    el.textContent = off ? '● Offline – showing saved data' : '● Online';
    el.className = `status ${off ? 'offline' : 'online'}`;
  }

  /* ---------- API ---------- */
  async function api(path, options = {}) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 8000);
    try {
      const res = await fetch(path, { ...options, signal: ctrl.signal });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) { const e = new Error(json.error?.message || `HTTP ${res.status}`); e.status = res.status; e.details = json.error?.details; throw e; }
      setOffline(false);
      return json.data;
    } catch (err) {
      if (err.status === undefined) setOffline(true); // network failure/timeout, not an API error
      throw err;
    } finally { clearTimeout(timer); }
  }

  /* ---------- data loading with offline fallback ---------- */
  async function loadVendors() {
    try { state.all = await api('/api/vendors'); writeLS(LS.vendors, state.all); }
    catch { state.all = readLS(LS.vendors, []); }
  }
  function filters() { return { q: $('search').value.trim(), area: $('area').value, specialty: $('specialty').value }; }
  function localFilter(f) {
    const q = f.q.toLowerCase();
    return state.all.filter((v) => (!q || [v.name, v.dishes, v.specialty, v.area].join(' ').toLowerCase().includes(q)) && (!f.area || v.area === f.area) && (!f.specialty || v.specialty === f.specialty));
  }
  async function refreshView() {
    const f = filters();
    const qs = new URLSearchParams(Object.entries(f).filter(([, v]) => v)).toString();
    try { state.view = qs ? await api(`/api/vendors?${qs}`) : state.all; }
    catch { state.view = localFilter(f); }
    renderVendors();
  }
  async function loadStats() {
    let s;
    try { s = await api('/api/stats'); writeLS(LS.stats, s); } catch { s = readLS(LS.stats, null); }
    const scored = state.all.map((v) => v.hygiene.score).filter((x) => x != null);
    $('vendorCount').textContent = s?.vendorCount ?? state.all.length;
    $('reviewCount').textContent = s?.reviewCount ?? '—';
    const top = s?.topScore ?? (scored.length ? Math.max(...scored) : null);
    $('topScore').textContent = top == null ? '—' : `${top.toFixed(1)}/5`;
  }
  async function loadTrail() {
    let trail; let cached = false;
    try { trail = await api('/api/trail?limit=3'); writeLS(LS.trail, trail); }
    catch { trail = readLS(LS.trail, []); cached = true; }
    $('trailTag').textContent = cached ? 'Saved offline copy' : 'Community pick';
    $('trailList').innerHTML = trail.length ? trail.map((t) => `<div class="trail"><div><b>${t.rank}. ${esc(t.name)}</b><div class="muted">${esc(t.area)} • ${esc(t.specialty)} • trust ${t.trust}%</div></div><span class="score">${fmtScore(t.score)} ★</span></div>`).join('') : '<div class="empty">No trail available yet.</div>';
  }

  /* ---------- rendering ---------- */
  function renderVendors() {
    $('vendorList').innerHTML = state.view.length ? state.view.map((v) => `<article class="vendor ${state.selectedId === v.id ? 'active' : ''}" tabindex="0" role="button" data-vendor="${v.id}" aria-label="${esc(v.name)}, hygiene score ${fmtScore(v.hygiene.score)}"><div class="vendor-top"><div><h3>${esc(v.name)}</h3><div class="meta">📍 ${esc(v.area)} • ${esc(v.landmark)}</div></div><div class="score">${fmtScore(v.hygiene.score)} ★</div></div><div class="meta">${esc(v.specialty)} • ${esc(v.price)} • ${esc(v.hours)}</div><div class="tags"><span class="tag">${esc(v.dishes)}</span>${v.fssai ? '<span class="tag good">🛡 FSSAI listed*</span>' : ''}<span class="tag ${v.open ? 'good' : 'red'}">${v.open ? 'Open (demo)' : 'Closed (demo)'}</span></div></article>`).join('') : '<div class="empty">No vendors match your filters.</div>';
  }
  async function selectVendor(id) {
    state.selectedId = id;
    let v = state.all.find((x) => x.id === id);
    try { v = await api(`/api/vendors/${id}`); } catch { /* fall back to list data */ }
    if (!v) return;
    let reviews = [];
    try { reviews = await api(`/api/vendors/${id}/reviews?limit=3`); } catch { /* offline: no reviews */ }
    const h = v.hygiene; const f = h.factors;
    $('detail').innerHTML = `<div class="eyebrow">Vendor details</div><div class="vendor-top"><h2>${esc(v.name)}</h2><div class="score">${fmtScore(h.score)} / 5 ★</div></div><p class="muted">📍 ${esc(v.area)} — ${esc(v.landmark)}</p><p>${esc(v.dishes)}</p><div class="tags">${v.fssai ? '<span class="tag good">🛡 FSSAI listed*</span>' : '<span class="tag">FSSAI status not confirmed</span>'}<span class="tag ${v.open ? 'good' : 'red'}">${v.open ? 'Open (demo)' : 'Closed (demo)'}</span><span class="tag trust">Trust ${h.trust}%</span><span class="tag">${esc(h.grade)}</span></div><div class="detail-grid"><div class="factor"><b>${f.water ?? '—'}/5</b><span>Clean / RO water (40%)</span></div><div class="factor"><b>${f.covered ?? '—'}/5</b><span>Covered food display (25%)</span></div><div class="factor"><b>${f.gloves ?? '—'}/5</b><span>Gloves / headgear (20%)</span></div><div class="factor"><b>${f.surroundings ?? '—'}/5</b><span>Surroundings (15%)</span></div></div><p class="muted">${h.score == null ? 'Not yet rated' : stars(h.score)} • ${h.reviewCount} reviews • ${esc(v.price)} • ${esc(v.hours)}</p><div class="reviews-list">${reviews.map((r) => `<div class="review"><time datetime="${esc(r.createdAt)}">${esc(new Date(r.createdAt).toLocaleDateString())}</time><div>${esc(r.comment) || '<i>No comment</i>'}</div>${r.photo ? `<img src="${esc(r.photo)}" alt="Stall photo from a review">` : ''}</div>`).join('')}</div><p class="muted">*Sample label only; not government-verified.</p>`;
    renderVendors();
    if (map && markers.has(id)) { map.setView([v.lat, v.lng], 14); markers.get(id).openPopup(); }
  }

  /* ---------- map ---------- */
  function initMap() {
    if (typeof L === 'undefined') { $('map').innerHTML = '<div class="empty">Map needs an internet connection to load. The vendor directory still works.</div>'; return; }
    map = L.map('map').setView([17.405, 78.46], 11);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; OpenStreetMap contributors', maxZoom: 19 }).addTo(map);
    for (const v of state.all) {
      const box = document.createElement('div');
      const b = document.createElement('b'); b.textContent = v.name;
      box.append(b, document.createElement('br'), document.createTextNode(`${fmtScore(v.hygiene.score)} / 5 hygiene score`));
      const m = L.marker([v.lat, v.lng]).addTo(map).bindPopup(box);
      m.on('click', () => selectVendor(v.id));
      markers.set(v.id, m);
    }
  }

  /* ---------- review modal + offline queue ---------- */
  const modal = $('reviewModal');
  function openReview() {
    $('reviewVendor').innerHTML = state.all.map((v) => `<option value="${v.id}" ${v.id === state.selectedId ? 'selected' : ''}>${esc(v.name)}</option>`).join('');
    $('formError').textContent = '';
    modal.classList.add('show'); $('reviewVendor').focus();
  }
  function closeReview() { modal.classList.remove('show'); }
  let photoData = null;
  async function shrinkImage(file) {
    const bmp = await createImageBitmap(file);
    const scale = Math.min(1, 640 / Math.max(bmp.width, bmp.height));
    const c = document.createElement('canvas'); c.width = Math.round(bmp.width * scale); c.height = Math.round(bmp.height * scale);
    c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
    for (const q of [0.7, 0.5, 0.3]) { const url = c.toDataURL('image/jpeg', q); if (url.length <= 190000) return url; }
    return null;
  }
  async function onPhoto(e) {
    const img = $('photoPreview'); photoData = null; img.style.display = 'none';
    const file = e.target.files[0]; if (!file) return;
    try {
      photoData = await shrinkImage(file);
      if (photoData) { img.src = photoData; img.style.display = 'block'; } else $('formError').textContent = 'That photo is too large; please choose a smaller one.';
    } catch { $('formError').textContent = 'Could not read that image.'; }
  }
  const queue = () => readLS(LS.queue, []);
  async function sendReview(item) { return api(`/api/vendors/${item.vendorId}/reviews`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(item.body) }); }
  async function flushQueue() {
    const pending = queue(); if (!pending.length) return;
    const left = [];
    for (const item of pending) {
      try { await sendReview(item); } catch (err) { if (err.status === undefined) left.push(item); /* drop items the server rejected */ }
    }
    writeLS(LS.queue, left);
    if (left.length < pending.length) { toast(`Synced ${pending.length - left.length} offline review(s).`); await refreshAll(); }
  }
  async function submitReview(e) {
    e.preventDefault();
    const body = { water: $('water').value, covered: $('covered').value, gloves: $('gloves').value, surroundings: $('surroundings').value, comment: $('comment').value, photo: photoData || undefined };
    const item = { vendorId: Number($('reviewVendor').value), body };
    try {
      await sendReview(item);
      toast('Thank you! Your review has updated the hygiene score.');
    } catch (err) {
      if (err.status !== undefined) { $('formError').textContent = err.details?.length ? err.details.map((d) => `${d.field}: ${d.message}`).join('; ') : err.message; return; }
      writeLS(LS.queue, [...queue(), item]);
      toast('You are offline. Review saved and will be sent when you reconnect.');
    }
    $('reviewForm').reset(); photoData = null; $('photoPreview').style.display = 'none'; closeReview();
    await refreshAll(); if (state.selectedId) await selectVendor(state.selectedId);
  }

  /* ---------- wiring ---------- */
  async function refreshAll() { await loadVendors(); await Promise.all([refreshView(), loadStats(), loadTrail()]); }
  function reset() { $('search').value = ''; $('area').value = ''; $('specialty').value = ''; refreshView(); }

  document.addEventListener('click', (e) => {
    const action = e.target.closest('[data-action]')?.dataset.action;
    if (action === 'open-review') openReview();
    else if (action === 'close-review') closeReview();
    else if (action === 'reset') reset();
    const card = e.target.closest('[data-vendor]');
    if (card) selectVendor(Number(card.dataset.vendor));
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeReview();
    const card = e.target.closest?.('[data-vendor]');
    if (card && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); selectVendor(Number(card.dataset.vendor)); }
  });
  modal.addEventListener('click', (e) => { if (e.target === modal) closeReview(); });
  $('reviewForm').addEventListener('submit', submitReview);
  $('photo').addEventListener('change', onPhoto);
  $('search').addEventListener('input', () => { clearTimeout(debounce); debounce = setTimeout(refreshView, 250); });
  $('area').addEventListener('change', refreshView);
  $('specialty').addEventListener('change', refreshView);
  window.addEventListener('online', () => { setOffline(false); flushQueue(); });
  window.addEventListener('offline', () => setOffline(true));

  (async function start() {
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
    await refreshAll();
    initMap();
    flushQueue();
  })();
})();
